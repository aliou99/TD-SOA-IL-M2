module.exports = {
  '{,src/**/}*.{json,md,yml,java}': ['prettier --write', 'git add']
};
