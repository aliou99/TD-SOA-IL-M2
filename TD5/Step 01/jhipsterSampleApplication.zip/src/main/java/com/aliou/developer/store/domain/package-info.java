/**
 * JPA domain objects.
 */
package com.aliou.developer.store.domain;
