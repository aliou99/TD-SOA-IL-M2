/**
 * Service layer beans.
 */
package com.aliou.developer.store.service;
