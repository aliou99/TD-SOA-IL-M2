/**
 * View Models used by Spring MVC REST controllers.
 */
package com.aliou.developer.store.web.rest.vm;
