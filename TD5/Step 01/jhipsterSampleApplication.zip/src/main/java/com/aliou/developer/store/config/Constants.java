package com.aliou.developer.store.config;

/**
 * Application constants.
 */
public final class Constants {
    public static final String SYSTEM_ACCOUNT = "system";

    private Constants() {}
}
