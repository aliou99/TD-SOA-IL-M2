/**
 * Spring Security configuration.
 */
package com.aliou.developer.store.security;
