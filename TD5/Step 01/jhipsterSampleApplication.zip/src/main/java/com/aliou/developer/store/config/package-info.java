/**
 * Spring Framework configuration files.
 */
package com.aliou.developer.store.config;
