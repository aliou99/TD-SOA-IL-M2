/**
 * Spring Data JPA repositories.
 */
package com.aliou.developer.store.repository;
