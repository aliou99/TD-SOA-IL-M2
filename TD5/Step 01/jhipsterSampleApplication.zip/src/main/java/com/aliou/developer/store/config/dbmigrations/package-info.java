/**
 * MongoDB database migrations using MongoBee.
 */
package com.aliou.developer.store.config.dbmigrations;
